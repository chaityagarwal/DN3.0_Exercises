public class Main {
    public static void main(String[] args) {
        TaskManagementSystem tms = new TaskManagementSystem();

        // Add tasks
        tms.addTask(new Task(1, "Task 1", "In Progress"));
        tms.addTask(new Task(2, "Task 2", "Completed"));
        tms.addTask(new Task(3, "Task 3", "Pending"));
        tms.addTask(new Task(4, "Task 4", "In Progress"));
        tms.addTask(new Task(5, "Task 5", "Completed"));

        // Traverse tasks
        System.out.println("Tasks:");
        tms.traverseTasks();

        // Search for a task
        Task task = tms.searchTask(3);
        if (task != null) {
            System.out.println("Task found: " + task.taskName);
        } else {
            System.out.println("Task not found.");
        }

        // Delete a task
        tms.deleteTask(2);
        System.out.println("Tasks after deletion:");
        tms.traverseTasks();
    }
}
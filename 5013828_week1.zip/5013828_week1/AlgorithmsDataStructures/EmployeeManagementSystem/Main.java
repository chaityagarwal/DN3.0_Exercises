public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        // Add employees
        ems.addEmployee(new Employee(1, "John Doe", "Software Engineer", 100000.0));
        ems.addEmployee(new Employee(2, "Jane Smith", "Marketing Manager", 120000.0));
        ems.addEmployee(new Employee(3, "Bob Johnson", "Sales Representative", 80000.0));
        ems.addEmployee(new Employee(4, "Alice Brown", "HR Manager", 110000.0));
        ems.addEmployee(new Employee(5, "Mike Davis", "IT Manager", 130000.0));

        // Traverse employees
        System.out.println("Employees:");
        ems.traverseEmployees();

        // Search for an employee
        Employee employee = ems.searchEmployee(2);
        if (employee != null) {
            System.out.println("Employee found: " + employee.name);
        } else {
            System.out.println("Employee not found.");
        }

        // Delete an employee
        ems.deleteEmployee(3);
        System.out.println("Employees after deletion:");
        ems.traverseEmployees();
    }
}
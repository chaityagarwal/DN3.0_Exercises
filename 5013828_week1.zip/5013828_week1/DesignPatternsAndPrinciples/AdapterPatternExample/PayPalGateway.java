public class PayPalGateway {
    public void payWithPayPal(double amount) {
        System.out.println("Processing PayPal payment of $" + amount);
    }
}
public class PayPalAdapter implements PaymentProcessor {
    private PayPalGateway paypalGateway;

    public PayPalAdapter() {
        this.paypalGateway = new PayPalGateway();
    }

    @Override
    public void processPayment(String paymentMethod, double amount) {
        if (paymentMethod.equals("PayPal")) {
            paypalGateway.payWithPayPal(amount);
        } else {
            System.out.println("Unsupported payment method");
        }
    }
}
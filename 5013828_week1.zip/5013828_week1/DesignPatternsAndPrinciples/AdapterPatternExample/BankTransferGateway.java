public class BankTransferGateway {
    public void transferFunds(double amount) {
        System.out.println("Transferring $" + amount + " via bank transfer");
    }
}
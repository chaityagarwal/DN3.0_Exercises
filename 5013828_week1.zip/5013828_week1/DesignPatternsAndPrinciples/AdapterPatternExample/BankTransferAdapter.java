public class BankTransferAdapter implements PaymentProcessor {
    private BankTransferGateway bankTransferGateway;

    public BankTransferAdapter() {
        this.bankTransferGateway = new BankTransferGateway();
    }

    @Override
    public void processPayment(String paymentMethod, double amount) {
        if (paymentMethod.equals("BankTransfer")) {
            bankTransferGateway.transferFunds(amount);
        } else {
            System.out.println("Unsupported payment method");
        }
    }
}
public class PdfDocumentImpl extends PdfDocument {
    public PdfDocumentImpl() {
        System.out.println("Creating PDF document...");
    }
}

package com.library.repository;

public class BookRepository {
    public void save(String bookName) {
        // Logic to save the book in the repository
        System.out.println("Saving book: " + bookName);
    }
}

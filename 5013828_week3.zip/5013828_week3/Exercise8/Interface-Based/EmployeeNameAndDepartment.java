public interface EmployeeNameAndDepartment {
    String getName();
    String getDepartmentName();
}
